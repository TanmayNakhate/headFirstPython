__author__ = 'dbohdan'
__copyright__ = 'Copyright (c) 2013, 2014, 2017 dbohdan'
__license__ = 'BSD'
__version__ = '2.0'
