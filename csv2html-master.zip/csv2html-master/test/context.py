import os
import sys
sys.path.insert(0, os.path.abspath('..'))

from csv2html import csv2html
